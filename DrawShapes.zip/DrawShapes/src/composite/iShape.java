package composite;

public interface iShape {
    public abstract void draw();
}
