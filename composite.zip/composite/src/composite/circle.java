package composite;

public class circle implements iShape {
    @Override
    public void draw() {
        System.out.println("Circle drawn");
    }
}
