package composite;

public class flag extends Composite {
    @Override
    public void build() {
        list.add(new rectangle());
        list.add(new circle());
    }
}
