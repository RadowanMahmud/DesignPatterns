package composite;

public class line implements iShape {

    @Override
    public void draw() {
        System.out.println("line drawn");
    }
}
