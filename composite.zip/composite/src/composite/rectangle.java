package composite;

public class rectangle extends Composite {
    @Override
    public void build() {
        list.add(new line());
        list.add(new line());
        list.add(new line());
        list.add(new line());
    }
}
