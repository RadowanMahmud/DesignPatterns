import composite.flag;
import composite.rectangle;

public class main {
    public static void main(String[] args) {
        flag n=new flag();
       // n.draw();
        rectangle r=new rectangle();
        r.draw();
    }
}
