package sample;

import java.io.File;

public interface ConvertFile {
    public void convertGivenFile(File outputfile);
}
