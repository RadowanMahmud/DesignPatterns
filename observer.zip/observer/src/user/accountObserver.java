package user;

public class accountObserver implements observer {
    @Override
    public void getNotification() {
        System.out.println("User is using personal account");
    }
}
