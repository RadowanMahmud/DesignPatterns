package user;

public class emailObserver implements observer {
    @Override
    public void getNotification() {
        System.out.println("This is for email user");
    }
}
