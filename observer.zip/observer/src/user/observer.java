package user;

public interface observer {
    public abstract void getNotification();
}
