package user;

public class smsObserver implements observer{
    @Override
    public void getNotification() {
        System.out.println("This is sms user");
    }
}
