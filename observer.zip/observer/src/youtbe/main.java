package youtbe;

import user.accountObserver;
import user.emailObserver;
import user.observer;
import user.smsObserver;

public class main {
    public static void main(String[] args) {
        observer a=new smsObserver();
        observer b=new emailObserver();
        observer c=new accountObserver();

        youtubeChannel u=new youtubeChannel();
        u.subscribe(a);
        u.subscribe(b);
        u.subscribe(c);
        u.upload();
        u.unsubscribe(b);
        u.upload();
    }
}
