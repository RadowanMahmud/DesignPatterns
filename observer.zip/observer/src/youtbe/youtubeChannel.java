package youtbe;

import user.accountObserver;
import user.emailObserver;
import user.observer;
import user.smsObserver;

import java.util.ArrayList;
import java.util.Iterator;

public class youtubeChannel {

    ArrayList<observer> list=new ArrayList<observer>();

    public void subscribe(observer a){
        list.add(a);
    }
    public void unsubscribe(observer a){
        list.remove(a);
    }
    public void notification(){
        Iterator<observer> iter = list.iterator();

        while (iter.hasNext()) {
            iter.next().getNotification();
        }
    }
    public void upload(){
        notification();;
    }

}
