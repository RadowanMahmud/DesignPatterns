public class main {
    public static void main(String[] args) {
        singleToneA a=singleToneA.getInstance(5);
        System.out.println(a.getc());
        singleToneA b=singleToneA.getInstance(500);
        System.out.println(b.getc());
    }
}
