public class singleToneA {

   // private static Object singleToneA;
    private int c;
    private singleToneA(int c){
        this.c=c;
    }

    private static singleToneA a= null;

    public static singleToneA getInstance(int c){
        if(a==null){
            synchronized (singleToneA.class){
                if(a==null){
                    a=new singleToneA(c);
                }
            }
        }
        return a;
    }
    public int getc(){
        return this.c;    }
}
