 class bkashStrategy implements payment {

     @Override
     public void execute(){
        System.out.println("You have chosen bkash");
    }
}
