import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        System.out.println("Enter your method");
        String s;
        Scanner cin=new Scanner(System.in);
        s=cin.nextLine();
        shopping ok=new shopping();
        if(s.equals("bkash")){
            ok.pay(new bkashStrategy());
        }
        else{
            ok.pay(new rocket());
        }
    }
}
