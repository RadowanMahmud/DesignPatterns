public interface payment {
    public void execute();
}
