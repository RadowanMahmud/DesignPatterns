public class rocket implements payment {

    @Override
    public void execute() {
        System.out.println("You have chosen rocket");
    }
}
