public class shopping {
    public void pay(payment i){
        i.execute();
    }
}
